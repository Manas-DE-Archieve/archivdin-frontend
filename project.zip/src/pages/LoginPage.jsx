import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { useAuth } from '../hooks/useAuth'

export default function LoginPage() {
  const { t } = useTranslation()
  const { login, register } = useAuth()
  const navigate = useNavigate()
  const [mode, setMode]       = useState('login')
  const [email, setEmail]     = useState('')
  const [password, setPassword] = useState('')
  const [error, setError]     = useState('')
  const [loading, setLoading] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      if (mode === 'login') await login(email, password)
      else await register(email, password)
      navigate('/')
    } catch (err) {
      setError(err.response?.data?.detail || t('common.error'))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-[88vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-sm animate-slide-up">
        {/* Logo / title block */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-primary-800 shadow-card-lg mb-4">
            <span className="font-serif text-2xl font-bold text-primary-200">А</span>
          </div>
          <h1 className="font-serif text-2xl font-bold text-primary-800">{t('app.title')}</h1>
          <p className="text-xs text-slate-400 mt-1 tracking-wide">{t('app.subtitle')}</p>
        </div>

        <div className="card p-7 shadow-card-lg">
          {/* Tab switcher */}
          <div className="flex rounded-lg overflow-hidden border border-slate-200 mb-6 bg-slate-50">
            {['login', 'register'].map(m => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`flex-1 py-2.5 text-sm font-medium tracking-wide transition-all duration-150 ${
                  mode === m
                    ? 'bg-primary-500 text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-700 hover:bg-white/50'
                }`}
              >
                {t(`auth.${m}`)}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="field-label block mb-1.5">{t('auth.email')}</label>
              <input
                className="input"
                type="email"
                required
                placeholder="example@mail.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
              />
            </div>
            <div>
              <label className="field-label block mb-1.5">{t('auth.password')}</label>
              <input
                className="input"
                type="password"
                required
                minLength={6}
                placeholder="••••••"
                value={password}
                onChange={e => setPassword(e.target.value)}
              />
            </div>

            {error && (
              <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2.5">
                <span className="shrink-0">⚠</span>
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full justify-center mt-2 !py-3"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                  {t('common.loading')}
                </span>
              ) : t(`auth.${mode}Btn`)}
            </button>
          </form>
        </div>

        <p className="text-center text-xs text-slate-400 mt-5">
          Цифровой мемориал · Кыргызстан 1918–1953
        </p>
      </div>
    </div>
  )
}
